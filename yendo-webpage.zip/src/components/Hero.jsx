import { motion } from 'framer-motion';

function Hero() {
  return (
    <section id="home" className="relative h-screen flex items-center justify-center">
      <div 
        className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1682687220742-aba13b6e50ba')] 
        bg-cover bg-center bg-fixed"
      >
        <div className="absolute inset-0 bg-gradient-overlay"></div>
      </div>
      
      <motion.div 
        className="relative text-center px-4"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 1 }}
      >
        <h1 className="text-4xl md:text-6xl font-bold mb-6">
          Explore the World with Yendo!
        </h1>
        <p className="text-xl md:text-2xl mb-8 max-w-2xl mx-auto">
          Your journey to extraordinary destinations begins here
        </p>
        <motion.button 
          className="bg-accent hover:bg-accent/80 text-white px-8 py-3 rounded-full 
          text-lg font-semibold transition-colors"
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
        >
          Start Your Adventure
        </motion.button>
      </motion.div>
    </section>
  );
}

export default Hero;