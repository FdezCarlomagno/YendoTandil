import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';

function About() {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.2
  });

  return (
    <section id="about" className="section-padding bg-secondary">
      <motion.div
        ref={ref}
        initial={{ opacity: 0 }}
        animate={inView ? { opacity: 1 } : {}}
        transition={{ duration: 1 }}
        className="max-w-4xl mx-auto text-center"
      >
        <h2 className="text-3xl md:text-4xl font-bold mb-8">About Yendo!</h2>
        <p className="text-lg text-gray-300 mb-6">
          At Yendo!, we believe that travel is more than just visiting new places – it's about creating 
          unforgettable moments and meaningful connections. Our mission is to transform your travel dreams 
          into reality, offering carefully curated experiences that combine adventure, culture, and comfort.
        </p>
        <p className="text-lg text-gray-300">
          With years of expertise and a passion for exploration, we craft journeys that inspire, educate, 
          and bring joy to travelers from all walks of life. Let us be your guide to the world's most 
          extraordinary destinations.
        </p>
      </motion.div>
    </section>
  );
}

export default About;