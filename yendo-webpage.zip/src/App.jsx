import { useEffect } from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import Experiences from './components/Experiences';
import About from './components/About';
import Contact from './components/Contact';
import PaperPlane from './components/PaperPlane';

function App() {
  useEffect(() => {
    const updateScroll = () => {
      const navbar = document.querySelector('.navbar');
      if (window.scrollY > 50) {
        navbar.classList.add('bg-primary/80', 'backdrop-blur-sm');
      } else {
        navbar.classList.remove('bg-primary/80', 'backdrop-blur-sm');
      }
    };

    window.addEventListener('scroll', updateScroll);
    return () => window.removeEventListener('scroll', updateScroll);
  }, []);

  return (
    <div className="relative">
      <Navbar />
      <PaperPlane />
      <main>
        <Hero />
        <Experiences />
        <About />
        <Contact />
      </main>
    </div>
  );
}

export default App;